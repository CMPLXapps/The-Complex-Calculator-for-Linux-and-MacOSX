#Packages

import math as m
from os import *
import random as r
import time as t

# Global Variables

A = 0
B = 0
C = 0
D = 0
E = 0
F = 0
pi = 3.14159265359
Pi = 3.14159265359
pI = 3.14159265359
PI = 3.14159265359
π = pi
e = 2.71828

# Math Functions

def fact(x):
  return m.factorial(eval(x))

def rt(x):
  return eval((1 / x))

def log(x):
  return m.log(x)

def rand(x, y):
  return r.randint(x, y)

def interest(x, y, z):
  return (x * ((1 + y) ** z))

# Functions



# --->>Startup Screen

def StartupScreen():
  #Function Variables-------------------------
  LabelTop = "+---------------------------------+"
  LabelName = "|  The Complex Calculator v3.0.0  |"
  LabelAuthor = "|            by CMPLX             |"
  LabelBottom = "+---------------------------------+"
  LabelPressENTER = "Press ENTER to Continue"
  LabelType_defvar = "Or input 'defvar' or 'dv' to define one of the variables.\n"
  LabelInput = ""

  #Function----------------------
  
  system('clear')
  print(LabelTop.center(100))
  print(LabelName.center(100))
  print(LabelAuthor.center(100))
  print(LabelBottom.center(100))
  print("\n" * 4)
  print(LabelPressENTER.center(100))
  print(LabelType_defvar.center(100))
  StartupInput = input(LabelInput.center(100))
  if StartupInput != "" and StartupInput != "dv" and StartupInput != "defvar":
    StartupScreenError()
  elif StartupInput == "dv" or StartupInput == "defvar":
    Screen_DVar()
  else:
    EquationScreen()

#------------>>If you didn't listen at the startup screen

def StartupScreenError():
  #Function Variables-------------------------
  LabelBorder = "+---------------------------------+"
  LabelName = "|  The Complex Calculator v3.0.0  |"
  LabelAuthor = "|            by CMPLX             |"
  LabelPressENTER = "I Said, Press ENTER to Continue"
  LabelType_defvar = "(Or type 'dv' or 'defvar'.)\n"
  LabelInput = ""

  #Function----------------------
  
  system('clear')
  print(LabelBorder.center(100))
  print(LabelName.center(100))
  print(LabelAuthor.center(100))
  print(LabelBorder.center(100))
  print("\n" * 4)
  print(LabelPressENTER.center(100))
  print(LabelType_defvar.center(100))
  StartupInput = input(LabelInput.center(100))
  while StartupInput != "":
    if StartupInput != "":
      StartupScreenError()
    else:
      EquationScreen()
  EquationScreen()

#------------>>Function Select Screen

def EquationScreen():
  
  #Function Variables
  global A, B, C, D, E, F, pi, pI, Pi, PI
  LabelBorder = "+-------------------------------------------------------------------------------------+"
  LabelScreen1 = "|  Taking a number to an exponent: X ** Y                                             |"
  LabelScreen3 = "|  Getting the Nth root of a number: X ** rt(Y)                                       |"
  LabelScreen4 = "|  Factorial: fact(x)                                                                 |"
  LabelScreen5 = "|  Using Pi and Euler's Number: π or pi for Pi, e for Euler's Number                  |"
  LabelScreen6 = "|  Log: log(X)                                                                        |"
  LabelScreen7 = "|  Log Base N: logn(X,N)                                                              |"
  LabelScreen8 = "|  Statistics: *mean, median, mode, or stdev*([LIST])                                 |"
  LabelRandInt = "|  Generating a Random Number: rand(*lowest number*, *highest number*)                |"
  LabelDebt =    "|  Calculate an owed debt: interest(*Start Amount*, *Interest rate*, *Elapsed Time*)  |"
  LabelBlank = "|  -You must put the rate in decimal form and the time in the same units as the rate  |"
  LabelType_rs = "|                      Type 'rs' or 'restart' to reload this screen,                  |"
  LabelType_back = "|                                or 'back' to go back.                                |"
  LabelType_CapVar = "|                    To reference a variable, use a capital letter.                   |"
  LabelVar = "\nA = " + str(A) + "\nB = " + str(B) + "\nC = " + str(C) + "\nD = " + str(D) + "\nE = " + str(E) + "\nF = " + str(F)

  #Function
  system('clear')
  print(LabelBorder.center(100))
  print(LabelScreen1.center(100))
  print(LabelScreen3.center(100))
  print(LabelScreen4.center(100))
  print(LabelScreen5.center(100))
  print(LabelScreen6.center(100))
  print(LabelScreen7.center(100))
  print(LabelScreen8.center(100))
  print(LabelRandInt.center(100))
  print(LabelDebt.center(100))
  print(LabelBlank.center(100))
  print(LabelType_rs.center(100))
  print(LabelType_back.center(100))
  print(LabelType_CapVar.center(100))
  print(LabelBorder.center(100))
  print(LabelVar)

  print("\n" * 4)
  
  print("Enter Your Equation:")
  EquationInput = input("\n>> ")

  while EquationInput == "back" or EquationInput == "rs":
    dummyVar1 = 1
    if EquationInput == "back":
      StartupScreen()
      break
    elif EquationInput == "rs":
      EquationScreen()
      break
    else:
      break
  try:
    system('clear')
    print(LabelBorder.center(100))
    print(LabelScreen1.center(100))
    print(LabelScreen3.center(100))
    print(LabelScreen4.center(100))
    print(LabelScreen5.center(100))
    print(LabelScreen6.center(100))
    print(LabelScreen7.center(100))
    print(LabelScreen8.center(100))
    print(LabelRandInt.center(100))
    print(LabelDebt.center(100))
    print(LabelBlank.center(100))
    print(LabelType_rs.center(100))
    print(LabelType_back.center(100))
    print(LabelType_CapVar.center(100))
    print(LabelBorder.center(100))
    print(LabelVar)

    print("\n" * 4)

    print("Here's the result:")
    ans = eval(EquationInput)
    print("\n>> " + str(eval(EquationInput)))
    input("Input anything or just press ENTER to clear  ")
    EquationScreen()
  except:
    system('clear')
    print(LabelBorder.center(100))
    print(LabelScreen1.center(100))
    print(LabelScreen3.center(100))
    print(LabelScreen4.center(100))
    print(LabelScreen5.center(100))
    print(LabelScreen6.center(100))
    print(LabelScreen7.center(100))
    print(LabelScreen8.center(100))
    print(LabelRandInt.center(100))
    print(LabelDebt.center(100))
    print(LabelBlank.center(100))
    print(LabelType_rs.center(100))
    print(LabelType_back.center(100))
    print(LabelType_CapVar.center(100))
    print(LabelBorder.center(100))
    print(LabelVar)

    print("\n" * 4)

    print("Sorry, you must have done something that caused an error.\nIf you're sure you didn't report this to CMPLX.")
    input("\nInput anything or just press ENTER to retry")
    EquationScreen()
def Screen_DVar():
  global A, B, C, D, E, F, pi, pI, Pi, PI
  def SDV_Board():
    system('clear')
    BackRSNotice = "Type 'back' to go back or 'rs' to reload this screen"
    print("+-----------------------+")
    print("|  Defining a Variable  |")
    print("+-----------------------+")
    print("\n" + BackRSNotice.center(100))
    print("\nA = " + str(A))
    print("B = " + str(B))
    print("C = " + str(C))
    print("D = " + str(D))
    print("E = " + str(E))
    print("F = " + str(F))
    print("\n" * 4)
  SDV_Board()
  VarSelectIndex = 0
  print("Enter the variable that you want to program (Capitalize it):")
  VarInput = input(">> ")
  while VarInput != "A" and VarInput != "B" and VarInput != "C" and VarInput != "D" and VarInput != "E" and VarInput != "F" and VarInput != "back" and VarInput != "rs":
    if VarInput != "A" and VarInput != "B" and VarInput != "C" and VarInput != "D" and VarInput != "E" and VarInput != "F" and VarInput != "back" and VarInput != "rs":
      print("Either you didn't capitalize the variable, or you didn't type the name of a variable, if you're sure that's not the case, report this to CMPLX.")
      input("Input anything or just press ENTER to retry")
      Screen_DVar()
    else:
      break
  while VarInput == "A":
    if VarInput == "A":
      VarSelectIndex = 1
      break
    else:
      break
  while VarInput == "B":
    if VarInput == "B":
      VarSelectIndex = 2
      break
    else:
      break
  while VarInput == "C":
    if VarInput == "C":
      VarSelectIndex = 3
      break
    else:
      break
  while VarInput == "D":
    if VarInput == "D":
      VarSelectIndex = 4
      break
    else:
      break
  while VarInput == "E":
    if VarInput == "E":
      VarSelectIndex = 5
      break
    else:
      break
  while VarInput == "F":
    if VarInput == "F":
      VarSelectIndex = 6
      break
    else:
      break
  while VarInput == "back":
    if VarInput == "back":
      StartupScreen()
      break
    else:
      break
  while VarInput == "rs":
    if VarInput == "rs":
      Screen_DVar()
      break
    else:
      break
  SDV_Board()
  print("Enter the value or equation that you want to store in this variable:")
  VarValue_input = input(">> ")
  try:
    VarValue = float(eval(VarValue_input))
  except:
    print("Sorry, that's not a valid input.")
    input("Input anything or just press ENTER to retry")
    Screen_DVar()
  if VarSelectIndex == 1:
    A = VarValue
    print("Variable Set...")
    input("Input anything or just press ENTER to restart")
    Screen_DVar()
  elif VarSelectIndex == 2:
    B = VarValue
    print("Variable Set...")
    input("Input anything or just press ENTER to restart")
    Screen_DVar()
  elif VarSelectIndex == 3:
    C = VarValue
    print("Variable Set...")
    input("Input anything or just press ENTER to restart")
    Screen_DVar()
  elif VarSelectIndex == 4:
    D = VarValue
    print("Variable Set...")
    input("Input anything or just press ENTER to restart")
    Screen_DVar()
  elif VarSelectIndex == 5:
    E = VarValue
    print("Variable Set...")
    input("Input anything or just press ENTER to restart")
    Screen_DVar()
  elif VarSelectIndex == 6:
    F = VarValue
    print("Variable Set...")
    input("Input anything or just press ENTER to restart")
    Screen_DVar()
StartupScreen()