import math
import os
import time
import random
import statistics as stat
A = 0
B = 0
C = 0
D = 0
E = 0
F = 0
pi = 3.14159265359
e = 2.7182818284590452353602874713527
tau = (2 * pi)
def variance(x):
  return stat.variance(x)
def sinh(x):
  return math.sinh(x)
def cosh(x):
  return math.cosh(x)
def tanh(x):
  return math.tanh(x)
def asinh(x):
  return math.asinh(x)
def acosh(x):
  return math.acosh(x)
def atanh(x):
  return math.atanh(x)
def mean(x):
  return stat.mean(x)
def median(x):
  return stat.median(x)
def mode(x):
  return stat.mode(x)
def stdev(x):
  return stat.stdev(x)
def sin(sinx):
  return abs(math.sin(sinx))
def cos(cosx):
  return abs(math.cos(cosx))
def tan(tanx):
  return abs(math.tan(tanx))
def asin(asinx):
  return abs(math.asin(asinx))
def acos(acosx):
  return abs(math.acos(acosx))
def atan(atanx):
  return abs(math.atan(atanx))
def logn(logbase, lognumber):
  return math.log(lognumber, logbase)
def log(log10number):
  return math.log(log10number, 10)
def fact(factorialn):
  return math.factorial(factorialn)
def root(rootnumber, nthroot):
  return (rootnumber ** (1 / nthroot))
def pcent(percentage, pcentn):
  return ((percentage / 100) * pcentn)
def equ():
  os.system('clear')
  print("+---------------------+")
  print("|  Solve an equation  |")
  print("+---------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  print("\n-Add = 'NUMBER + ADDITIVE'                          -Sine = 'sin(NUMBER)'")
  print("-Subtract = 'NUMBER - SUBTRACTOR'                   -Cosine = 'cos(NUMBER)'")
  print("-Multiply = 'NUMBER * MULTIPLICATOR'                -Tangent = 'tan(NUMBER)'")
  print("-Divide = 'DIVIDEND / DIVISOR'                      -Inverse Sine = 'asin(NUMBER)'")
  print("-Power = ' NUMBER ** EXPONENT '                     -Inverse Cosine = 'acos(NUMBER)'")
  print("-Root = 'root(NUMBER, NTH ROOT)'                    -Inverse Tangent = 'atan(NUMBER)'")
  print("-Factorial = 'fact(NUMBER)'                         -Pi = 'pi'")
  print("-Logarithm (Base 'n') = 'logn(BASE, NUMBER)'        -Modulus = 'DIVIDEND % DIVISOR'")
  print("-Logarithm (Default, Base 10) = 'log(NUMBER)'       -Percent = 'pcent(PERCENTAGE, NUMBER)'")
  print("-Absolute Value = 'abs(NUMBER OR EQUATION)'         -Euler's Number (e) = 'e'")
  print("-Mean = 'mean(NUMBER SET)'                          -Median = median(NUMBER SET)")
  print("-Mode = 'mode(NUMBER SET)'                          -Standard Deviation = 'stdev(NUMBER SET)'")
  print("-Variance = 'variance(NUMBER SET)'                  -Tau = 'tau'")
  print("-Hyperbolic Sine = 'sinh(NUMBER)'                   -Inverse Hyperbolic Sine = 'asinh(NUMBER)'")
  print("-Hyperbolic Cosine = 'cosh(NUMBER)'                 -Inverse Hyperbolic Cosine = 'acosh(NUMBER)'")
  print("-Hyperbolic Tangent = 'tanh(NUMBER)'                -Inverse Hyperbolic Tangent = 'atanh(NUMBER)'")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  print("\n(To reference a variable, it needs to be capitalized)")
  RawEquationInput = input("\nType your equation: ")
  print("\nLoading...")
  while RawEquationInput == "back" or RawEquationInput == "b":
    if RawEquationInput == "back" or RawEquationInput == "b":
      strt()
    else:
      break
  try:
    os.system('clear')
    print("+---------------------+")
    print("|  Solve an Equation  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-Add = 'NUMBER + ADDITIVE'                          -Sine = 'sin(NUMBER)'")
    print("-Subtract = 'NUMBER - SUBTRACTOR'                   -Cosine = 'cos(NUMBER)'")
    print("-Multiply = 'NUMBER * MULTIPLICATOR'                -Tangent = 'tan(NUMBER)'")
    print("-Divide = 'DIVIDEND / DIVISOR'                      -Inverse Sine = 'asin(NUMBER)'")
    print("-Power = ' NUMBER ** EXPONENT '                     -Inverse Cosine = 'acos(NUMBER)'")
    print("-Root = 'root(NUMBER, NTH ROOT)'                    -Inverse Tangent = 'atan(NUMBER)'")
    print("-Factorial = 'fact(NUMBER)'                         -Pi = 'pi'")
    print("-Logarithm (Base 'n') = 'logn(BASE, NUMBER)'        -Modulus = 'DIVIDEND % DIVISOR'")
    print("-Logarithm (Default, Base 10) = 'log(NUMBER)'       -Percent = 'pcent(PERCENTAGE, NUMBER)'")
    print("-Absolute Value = 'abs(NUMBER OR EQUATION)'         -Euler's Number (e) = 'e'")
    print("-Mean = 'mean(NUMBER SET)'                          -Median = median(NUMBER SET)")
    print("-Mode = 'mode(NUMBER SET)'                          -Standard Deviation = 'stdev(NUMBER SET)'")
    print("-Variance = 'variance(NUMBER SET)'                  -Tau = 'tau'")
    print("-Hyperbolic Sine = 'sinh(NUMBER)'                   -Inverse Hyperbolic Sine = 'asinh(NUMBER)'")
    print("-Hyperbolic Cosine = 'cosh(NUMBER)'                 -Inverse Hyperbolic Cosine = 'acosh(NUMBER)'")
    print("-Hyperbolic Tangent = 'tanh(NUMBER)'                -Inverse Hyperbolic Tangent = 'atanh(NUMBER)'")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\n(To reference a variable, it needs to be capitalized)")
    EvaluatedEquation = eval(RawEquationInput)
    print("\nHere's the result: " + str(EvaluatedEquation))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("\nInput anything to try again: ")
    equ()
  input("\nInput anything to try again: ")
  equ()
def dvar():
  VariableSelectionIndex = 0
  global A, B, C, D, E, F
  os.system('clear')
  print("+---------------------+")
  print("|  Define a variable  |")
  print("+---------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  VariableInQuestion = input("\nWhat variable do you want to program?> ")
  print("\nLoading...")
  while VariableInQuestion == "back":
    if VariableInQuestion == "back":
      strt()
    else:
      break
  while VariableInQuestion == "A" or VariableInQuestion == "a":
    if VariableInQuestion == "A" or VariableInQuestion == "a":
      VariableSelectionIndex = 1
      break
    else:
      break
  while VariableInQuestion == "B" or VariableInQuestion == "b":
    if VariableInQuestion == "B" or VariableInQuestion == "b":
      VariableSelectionIndex = 2
      break
    else:
      break
  while VariableInQuestion == "C" or VariableInQuestion == "c":
    if VariableInQuestion == "C" or VariableInQuestion == "c":
      VariableSelectionIndex = 3
      break
    else:
      break
  while VariableInQuestion == "D" or VariableInQuestion == "d":
    if VariableInQuestion == "D" or VariableInQuestion == "d":
      VariableSelectionIndex = 4
      break
    else:
      break
  while VariableInQuestion == "E" or VariableInQuestion == "e":
    if VariableInQuestion == "E" or VariableInQuestion == "e":
      VariableSelectionIndex = 5
      break
    else:
      break
  while VariableInQuestion == "F" or VariableInQuestion == "f":
    if VariableInQuestion == "F" or VariableInQuestion == "f":
      VariableSelectionIndex = 6
      break
    else:
      break
  while VariableSelectionIndex == 0:
    if VariableSelectionIndex == 0:
      print("There is no such variable as '" + VariableInQuestion + "'.")
      input("Input anything to try again: ")
      dvar()
    else:
      break
  os.system('clear')
  print("+---------------------+")
  print("|  Define a variable  |")
  print("+---------------------+")
  print("\n(To Reference another variable, it needs to be capitalized.)")
  print("\nType 'back' at any time to start back at the main menu.")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  VariableNewValue = input("\nEnter the equation or number that you want to program into that variable: ")
  print("\nLoading...")
  while VariableNewValue == "back" or VariableNewValue == "b":
    if VariableNewValue == "back" or VariableNewValue == "b":
      strt()
    else:
      break
  try:
    eval_VariableNewValue = eval(VariableNewValue)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nChecking if " + str(eval_VariableNewValue) + " is valid...")
  except:
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("\nInput anything to try again: ")
    dvar()
  if VariableSelectionIndex == 1:
    A = eval(VariableNewValue)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif VariableSelectionIndex == 2:
    B = eval(VariableNewValue)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif VariableSelectionIndex == 3:
    C = eval(VariableNewValue)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif VariableSelectionIndex == 4:
    D = eval(VariableNewValue)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif VariableSelectionIndex == 5:
    E = eval(VariableNewValue)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif VariableSelectionIndex == 6:
    F = eval(VariableNewValue)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  else:
    print("This mesage is the result of a glitch, if you are seeing this report it to the developer. Ignore this: var-if-selec-is-0-didnt-work")
def intrst():
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  StartingAmount = input("\nWhat was the starting StartingAmount owed?> ")
  print("\nLoading...")
  while StartingAmount == "back" or StartingAmount == "b":
    if StartingAmount == "back" or StartingAmount == "b":
      strt()
    else:
      break
  try:
    print("You entered: " + str(float(StartingAmount)))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("Input anything to try again: ")
    dvar()
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  InterestRate = input("\nWhat is the interest InterestRate (as a decimal)?> ")
  print("\nLoading...")
  while InterestRate == "back" or InterestRate == "b":
    if InterestRate == "back" or InterestRate == "b":
      strt()
    else:
      break
  try:
    print("You entered: " + str(float(InterestRate)))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("Input anything to try again: ")
    dvar()
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  ElapsedTime = input("\nEnter the elapsed time in the same time units as the interest InterestRate: ")
  print("\nLoading...")
  while ElapsedTime == "back" or ElapsedTime == "b":
    if ElapsedTime == "back" or ElapsedTime == "b":
      strt()
    else:
      break
  try:
    print("You entered: " + str(float(ElapsedTime)))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("Input anything to try again: ")
    dvar()
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  debt = (float(StartingAmount) * (1 + float(InterestRate)) ** float(ElapsedTime))
  print("\nYou now owe: " + str(debt))
  input("Input anything to try again: ")
  dvar()
def strt():
  os.system('clear')
  print("+---------------------------------+")
  print("|  The Complex Calculator v2.0.0  |")
  print("|            by  CMPLX            |")
  print("+---------------------------------+")
  print("Enter 'restart' to reload ths menu.")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  print("\nOptions:")
  print("\n-Solve an equation ('equ')\n-Define a variable ('defvar')\n-Calculate an owed debt ('interest')")
  strtcmd = input("\nWhat would you like to do?> ")
  print("Loading...")
  if strtcmd == "e" or strtcmd == "equ" or strtcmd == "eq":
    equ()
  elif strtcmd == "def" or strtcmd == "var" or strtcmd == "defvar" or strtcmd == "dv" or strtcmd == "v" or strtcmd == "d":
    try:
      dvar()
    except SyntaxError:
      pass
  elif strtcmd == "i" or strtcmd == "int" or strtcmd == "interest":
    intrst()
  elif strtcmd == "restart" or strtcmd == "rstrt" or strtcmd == "rstart" or strtcmd == "rs" or strtcmd == "r":
    strt()
  else:
    print("Sorry, I don't know how to '" + strtcmd + "', restarting...")
    time.sleep(2)
    strt()
strt()