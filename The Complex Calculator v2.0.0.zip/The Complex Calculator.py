import math
import os
import time
import random
A = 0
B = 0
C = 0
D = 0
E = 0
F = 0
pi = 3.14159265359
e = 2.7182818284590452353602874713527
def sin(sinx):
  return abs(math.sin(sinx))
def cos(cosx):
  return abs(math.cos(cosx))
def tan(tanx):
  return abs(math.tan(tanx))
def asin(asinx):
  return abs(math.asin(asinx))
def acos(acosx):
  return abs(math.acos(acosx))
def atan(atanx):
  return abs(math.atan(atanx))
def logn(logbase, lognumber):
  return math.log(lognumber, logbase)
def log(log10number):
  return math.log(log10number, 10)
def fact(factorialn):
  return math.factorial(factorialn)
def root(rootnumber, nthroot):
  return (rootnumber ** (1 / nthroot))
def pcent(percentage, pcentn):
  return ((percentage / 100) * pcentn)
def equ():
  os.system('clear')
  print("+---------------------+")
  print("|  Solve an equation  |")
  print("+---------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  print("\n-Add = 'NUMBER + ADDITIVE'                          -Sine = 'sin(NUMBER)'")
  print("-Subtract = 'NUMBER - SUBTRACTOR'                   -Cosine = 'cos(NUMBER)'")
  print("-Multiply = 'NUMBER * MULTIPLICATOR'                -Tangent = 'tan(NUMBER)'")
  print("-Divide = 'DIVIDEND / DIVISOR'                      -Inverse Sin = 'asin(NUMBER)'")
  print("-Power = ' NUMBER ** EXPONENT '                     -Inverse Cosine = 'acos(NUMBER)'")
  print("-Root = 'root(NUMBER, NTH ROOT)'                    -Inverse Tangent = 'atan(NUMBER)'")
  print("-Factorial = 'fact(NUMBER)'                         -Pi = 'pi'")
  print("-Logarithm (Base 'n') = 'logn(BASE, NUMBER)'        -Modulus = 'DIVIDEND % DIVISOR'")
  print("-Logarithm (Default, Base 10) = 'log(NUMBER)'       -Percent = 'pcent(PERCENTAGE, NUMBER)'")
  print("-Absolute Value = 'abs(NUMBER OR EQUATION)'         -Euler's Number (e) = 'e'")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  print("\n(To reference a variable, it needs to be capitalized)")
  strequation = input("\nType your equation: ")
  print("\nLoading...")
  while strequation == "back" or strequation == "b":
    if strequation == "back" or strequation == "b":
      strt()
    else:
      break
  try:
    os.system('clear')
    print("+---------------------+")
    print("|  Solve an equation  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-Add = 'NUMBER + ADDITIVE'                          -Sine = 'sin(NUMBER)'")
    print("-Subtract = 'NUMBER - SUBTRACTOR'                   -Cosine = 'cos(NUMBER)'")
    print("-Multiply = 'NUMBER * MULTIPLICATOR'                -Tangent = 'tan(NUMBER)'")
    print("-Divide = 'DIVIDEND / DIVISOR'                      -Inverse Sin = 'asin(NUMBER)'")
    print("-Power = ' NUMBER ** EXPONENT '                     -Inverse Cosine = 'acos(NUMBER)'")
    print("-Root = 'root(NUMBER, NTH ROOT)'                    -Inverse Tangent = 'atan(NUMBER)'")
    print("-Factorial = 'fact(NUMBER)'                         -Pi = 'pi'")
    print("-Logarithm (Base 'n') = 'logn(BASE, NUMBER)'        -Modulus = 'DIVIDEND % DIVISOR'")
    print("-Logarithm (Default, Base 10) = 'log(NUMBER)'       -Percent = 'pcent(PERCENTAGE, NUMBER)'")
    print("-Absolute Value = 'abs(NUMBER OR EQUATION)'         -Euler's Number (e) = 'e'")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\n(To reference a variable, it needs to be capitalized)")
    equation = eval(strequation)
    print("\nHere's the result: " + str(equation))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("\nInput anything to try again: ")
    equ()
  input("\nInput anything to try again: ")
  equ()
def dvar():
  vartgc = 0
  global A, B, C, D, E, F
  os.system('clear')
  print("+---------------------+")
  print("|  Define a variable  |")
  print("+---------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  var_in_ques = input("\nWhat variable do you want to program?> ")
  print("\nLoading...")
  while var_in_ques == "back":
    if var_in_ques == "back":
      strt()
    else:
      break
  while var_in_ques == "A" or var_in_ques == "a":
    if var_in_ques == "A" or var_in_ques == "a":
      vartgc = 1
      break
    else:
      break
  while var_in_ques == "B" or var_in_ques == "b":
    if var_in_ques == "B" or var_in_ques == "b":
      vartgc = 2
      break
    else:
      break
  while var_in_ques == "C" or var_in_ques == "c":
    if var_in_ques == "C" or var_in_ques == "c":
      vartgc = 3
      break
    else:
      break
  while var_in_ques == "D" or var_in_ques == "d":
    if var_in_ques == "D" or var_in_ques == "d":
      vartgc = 4
      break
    else:
      break
  while var_in_ques == "E" or var_in_ques == "e":
    if var_in_ques == "E" or var_in_ques == "e":
      vartgc = 5
      break
    else:
      break
  while var_in_ques == "F" or var_in_ques == "f":
    if var_in_ques == "F" or var_in_ques == "f":
      vartgc = 6
      break
    else:
      break
  while vartgc == 0:
    if vartgc == 0:
      print("There is no such variable as '" + var_in_ques + "'.")
      input("Input anything to try again: ")
      dvar()
    else:
      break
  os.system('clear')
  print("+---------------------+")
  print("|  Define a variable  |")
  print("+---------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  var_new_value = input("\nEnter the equation or number that you want to program into that variable: ")
  print("\nLoading...")
  while var_new_value == "back" or var_new_value == "b":
    if var_new_value == "back" or var_new_value == "b":
      strt()
    else:
      break
  try:
    eval_var_new_value = eval(var_new_value)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nChecking if " + str(eval_var_new_value) + " is valid...")
  except:
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("\nInput anything to try again: ")
    dvar()
  if vartgc == 1:
    A = eval(var_new_value)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif vartgc == 2:
    B = eval(var_new_value)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif vartgc == 3:
    C = eval(var_new_value)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif vartgc == 4:
    D = eval(var_new_value)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif vartgc == 5:
    E = eval(var_new_value)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  elif vartgc == 6:
    F = eval(var_new_value)
    os.system('clear')
    print("+---------------------+")
    print("|  Define a variable  |")
    print("+---------------------+")
    print("\nType 'back' at any time to start back at the main menu.")
    print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
    print("\nSuccessful!")
    input("Input anything to try again: ")
    dvar()
  else:
    print("This mesage is the result of a glitch, if you are seeing this report it to the developer. Ignore this: var-if-selec-is-0-didnt-work")
def intrst():
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  amount = input("\nWhat was the starting amount owed?> ")
  print("\nLoading...")
  while amount == "back" or amount == "b":
    if amount == "back" or amount == "b":
      strt()
    else:
      break
  try:
    print("You entered: " + str(float(amount)))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("Input anything to try again: ")
    dvar()
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  rate = input("\nWhat is the interest rate (as a decimal)?> ")
  print("\nLoading...")
  while rate == "back" or rate == "b":
    if rate == "back" or rate == "b":
      strt()
    else:
      break
  try:
    print("You entered: " + str(float(rate)))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("Input anything to try again: ")
    dvar()
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  itime = input("\nEnter the elapsed time in the same time units as the interest rate: ")
  print("\nLoading...")
  while itime == "back" or itime == "b":
    if itime == "back" or itime == "b":
      strt()
    else:
      break
  try:
    print("You entered: " + str(float(itime)))
  except:
    print("\nSorry, you must have either mistyped something, input a nil variable, tried to divide by zero, typed nothing, or done something else that caused an error, if you're sure that you didn't, please report this to the developer.")
    input("Input anything to try again: ")
    dvar()
  os.system('clear')
  print("+--------------------------+")
  print("|  Calculate an owed debt  |")
  print("+--------------------------+")
  print("\nType 'back' at any time to start back at the main menu.")
  debt = (float(amount) * (1 + float(rate)) ** float(itime))
  print("\nYou now owe: " + str(debt))
  input("Input anything to try again: ")
  dvar()
def strt():
  os.system('clear')
  print("+---------------------------------+")
  print("|  The Complex Calculator v2.0.0  |")
  print("|            by  CMPLX            |")
  print("+---------------------------------+")
  print("Enter 'restart' to reload ths menu.")
  print("\n-A = " + str(A) + "\n-B = " + str(B) + "\n-C = " + str(C) + "\n-D = " + str(D) + "\n-E = " + str(E) + "\n-F = " + str(F))
  print("\nOptions:")
  print("\n-Solve an equation ('equ')\n-Define a variable ('defvar')\n-Calculate an owed debt ('interest')")
  strtcmd = input("\nWhat would you like to do?> ")
  if strtcmd == "e" or strtcmd == "equ" or strtcmd == "eq":
    equ()
  elif strtcmd == "def" or strtcmd == "var" or strtcmd == "defvar" or strtcmd == "dv" or strtcmd == "v" or strtcmd == "d":
    try:
      dvar()
    except SyntaxError:
      pass
  elif strtcmd == "i" or strtcmd == "int" or strtcmd == "interest":
    intrst()
  elif strtcmd == "restart" or strtcmd == "rstrt" or strtcmd == "rstart" or strtcmd == "rs" or strtcmd == "r":
    strt()
  else:
    print("Sorry, I don't know how to '" + strtcmd + "', restarting...")
    time.sleep(2)
    strt()
strt()