from math import *
import os
import time
import random
a = 0
b = 0
c = 0
d = 0
e = 0
f = 0
pi = 3.14159265359
def strt():
  os.system('clear')
  print("+---------------------------------+")
  print("|  The Complex Calculator v2.0.0  |")
  print("|            by  CMPLX            |")
  print("+---------------------------------+")
  print("\nOptions:")
  print("\n-Solve an equation ('equ')\n-Define a variable ('defvar')\n-Calculate an owed debt ('interest')")
  strtcmd = input("\nWhat would you like to do?> ")
  if strtcmd == "e" or "equ":
    def equ():
      os.system('clear')
      print("-Add = '+'                    -Sine = 'sin(x)'")
      print("-Subtract = '-'               -Cosine = 'cos(x)'")
      print("-Multiply = '*'               -Tangent = 'tan(x)'")
      print("-Divide = '/'                 -Inverse Sin = 'asin(x)'")
      print("-Power = '**'                 -Inverse Cosine = 'acos(x)'")
      print("-Root = '** (1 / x)'          -Inverse Tangent = 'atan(x)'")
      print("-Factorial = 'factorial(x)'   -Pi = 'pi'")
      print("\n(If you use the trig functions, it will make them negative, so use absolute value ('abs()') )")
      print("\n-a = " + str(a) + "\n-b = " + str(b) + "\n-c = " + str(c) + "\n-d = " + str(d) + "\n-e = " + str(e) + "\n-f = " + str(f))
      equation = eval(input("\nType your equation: "))
      try:
        print("Here's the result: " + str(equation))
      except ValueError:
        print("Sorry, you must have used a nil variable, or you mistyped something, if you're sure you didn't, report this the developer. Restarting...")
        time.sleep(1)
        strt()
      input("Input anything to restart: ")
      strt()
    equ()
  elif strtcmd == "def" or strtcmd == "var" or strtcmd == "defvar" or strtcmd == "dv" or strtcmd == "v" or strtcmd == "d":
    print("i")
  elif strtcmd == "i" or "int" or "interest":
    print("i")
strt()